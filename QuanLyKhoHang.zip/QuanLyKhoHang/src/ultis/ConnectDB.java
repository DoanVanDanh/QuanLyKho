package ultis;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDB {
	private String url = "jdbc:sqlserver://localhost:20401;databaseName=NhapXuatKho";
	private String userName = "sa";
	private String password = "Abcde12345";
	private Connection connection;
	
	
	public ConnectDB() {
		connect();
	}

	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	public static void main(String[] args) {
		ConnectDB connectDB = new ConnectDB();
		
	}
	
}
