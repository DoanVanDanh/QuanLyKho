package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.bean.TaiKhoan;
import ultis.ConnectDB;

public class TaiKhoanDAO {
	private Connection con = null;
	private ConnectDB connectDB;

	public TaiKhoanDAO() {
		connectDB = new ConnectDB();
		con = connectDB.getConnection();
	}


	public String getMatKhau(String tenDangNhap) {
		String sql = "select MatKhau from TAIKHOAN where TenTK = ?";
		String matKhau = null;
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, tenDangNhap);
			ResultSet rs = ps.executeQuery();

			while(rs.next()){
				matKhau = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return matKhau;
	}


	public TaiKhoan getTaiKhoan(String tenDangNhap) {
		String sql = "select * from TAIKHOAN where TenTK =?";
		TaiKhoan taiKhoan = new TaiKhoan();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, tenDangNhap);
			ResultSet rs = ps.executeQuery();

			while(rs.next()){
				String matKhau = rs.getString(2);
				String maChucNang = rs.getString(3);
				taiKhoan.setMatKhau(matKhau);
				taiKhoan.setMaChucNang(maChucNang);
				taiKhoan.setTenDangNhap(tenDangNhap);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return taiKhoan;
	}
	public static void main(String[] args) {
		TaiKhoanDAO taiKhoanDAO = new TaiKhoanDAO();
		
	}

}
