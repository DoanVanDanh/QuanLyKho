package model.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;

import model.bean.NhanVien;
import ultis.ConnectDB;

public class NhanVienDAO {
	private Connection con = null;
	private ConnectDB connectDB;

	public NhanVienDAO() {
		connectDB = new ConnectDB();
		con = connectDB.getConnection();
	}
	
	
	public boolean insertNhanVien(NhanVien nhanVien){
		boolean isSucess = false;
		
		try {
			String sql = "insert into NHANVIEN(TenNV, ChucVu,NgaySinh,GioiTinh,DiaChi,AnhDaiDien) "+
						"values (?,?,?,?,?,?)";
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,nhanVien.getTenNV() );
			ps.setString(2, nhanVien.getChucVu());
			ps.setDate(3, nhanVien.getNgaySinh());
			ps.setString(4, nhanVien.getGioiTinh());
			ps.setString(5, nhanVien.getDiaChi());
			ps.setString(6, nhanVien.getAnhDaiDien());
//			ps.setString(6, nhanVien.getSoDienThoai());
//			ps.setString(7, nhanVien.getEmail());
			
			isSucess = ps.executeUpdate()>0;
			System.out.println("da them thanh cong");
		} catch (Exception e) {
			System.out.println("loi : insert NhanVien \n"+ e.getMessage());
		}
		
		
		return isSucess;
	}
	public static void main(String[] args) {
		Date date = new Date(1111);
		NhanVien nhanVien = new NhanVien(null,"aaa","bb", "a", date, "0", "a",null,null);
		
		
		NhanVienDAO nhanVienDAO = new NhanVienDAO();
		nhanVienDAO.insertNhanVien(nhanVien);
		
	}
}
