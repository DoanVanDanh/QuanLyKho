package model.bo;

import model.dao.NhanVienDAO;

public class NhanVienBO {
	NhanVienDAO nhanVienDAO = new NhanVienDAO();

	public NhanVienDAO getNhanVienDAO() {
		return nhanVienDAO;
	}

	public void setNhanVienDAO(NhanVienDAO nhanVienDAO) {
		this.nhanVienDAO = nhanVienDAO;
	}
	
	

}
