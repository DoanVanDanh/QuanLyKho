package model.bean;

public class PhuongXa {
	private String ma;
	private String ten;
	
	
	public PhuongXa() {
		// TODO Auto-generated constructor stub
	}
	
	
	public PhuongXa(String ma, String ten) {
		super();
		this.ma = ma;
		this.ten = ten;
	}


	public String getMa() {
		return ma;
	}
	public void setMa(String ma) {
		this.ma = ma;
	}
	public String getTen() {
		return ten;
	}
	public void setTen(String ten) {
		this.ten = ten;
	}
}
